%%%%%%%%%%%%%%%%%%%main program to generate signals%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%%%%%%%%set up environment%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear;  close all;
addpath('Signal');
addpath('CWD');
rng('shuffle','twister');                %seed for rand


%% %%%%%%%%%%%%%%%%%%%image set up%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
path = {'Image/Known/P1/','Image/Known/P2/','Image/Known/P3/','Image/Known/P4/'...
        'Image/Known/Frank/','Image/Known/LFM/','Image/Known/Costas/','Image/Known/Barker/'};
prefix =  {'P1_','P2_','P3_','P4_'...
        'Frank_','LFM_','Costas_','Barker_'};
format = 'jpg';
suffix = strcat('.',format);
nt = 8;                         %# of types of signal
nd = 300;                       %# of signals generating under certain SNR
ns = 6;                         %# of SNR
A = 1:1:nd*ns;
name = string(A);
S = cell(6,300);   %store signal


%% %%%%%%%%%%%%noise set up%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    SNR_dB = [0 2 4 6 8 10];
    SNR = 10.^(SNR_dB/10);
    Am = 1;
    power = 10*log10(Am^2./(2*SNR));

    
%% %%%%%%%%%%%%%%%%%%%%%%%%P1 Signal CWD%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:length(power)
    for i =1:nd
        x = P1_Code();
        S{j,i} = x + wgn(1,length(x),power(j));
    end
end


  for j =1:length(power)
      for i =1:nd
        CWD = choiwilliams(S{j,i});
        CWD = abs(CWD);
        CWD = (CWD-min(CWD))./(max(CWD)-min(CWD)); %generalization
        imwrite(CWD,strcat(path{1},prefix{1},name((j-1)*300+i),suffix),format);
      end
  end
  
  
  %% %%%%%%%%%%%%%%%%%%%%%%%%P2 Signal CWD%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:length(power)
    for i =1:nd
        x = P2_Code();
        S{j,i} = x + wgn(1,length(x),power(j));
    end
end


  for j =1:length(power)
      for i =1:nd
        CWD = choiwilliams(S{j,i});
        CWD = abs(CWD);
        CWD = (CWD-min(CWD))./(max(CWD)-min(CWD)); %generalization
        imwrite(CWD,strcat(path{2},prefix{2},name((j-1)*300+i),suffix),format);
      end
  end
  
  
    %% %%%%%%%%%%%%%%%%%%%%%%%%P3 Signal CWD%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:length(power)
    for i =1:nd
        x = P3_Code();
        S{j,i} = x + wgn(1,length(x),power(j));
    end
end


  for j =1:length(power)
      for i =1:nd
        CWD = choiwilliams(S{j,i});
        CWD = abs(CWD);
        CWD = (CWD-min(CWD))./(max(CWD)-min(CWD)); %generalization
        imwrite(CWD,strcat(path{3},prefix{3},name((j-1)*300+i),suffix),format);
      end
  end
  
  
      %% %%%%%%%%%%%%%%%%%%%%%%%%P4 Signal CWD%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:length(power)
    for i =1:nd
        x = P4_Code();
        S{j,i} = x + wgn(1,length(x),power(j));
    end
end


  for j =1:length(power)
      for i =1:nd
        CWD = choiwilliams(S{j,i});
        CWD = abs(CWD);
        CWD = (CWD-min(CWD))./(max(CWD)-min(CWD)); %generalization
        imwrite(CWD,strcat(path{4},prefix{4},name((j-1)*300+i),suffix),format);
      end
  end
  
  
      %% %%%%%%%%%%%%%%%%%%%%%%%%Frank Signal CWD%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:length(power)
    for i =1:nd
        x = Frank_Code();
        S{j,i} = x + wgn(1,length(x),power(j));
    end
end


  for j =1:length(power)
      for i =1:nd
        CWD = choiwilliams(S{j,i});
        CWD = abs(CWD);
        CWD = (CWD-min(CWD))./(max(CWD)-min(CWD)); %generalization
        imwrite(CWD,strcat(path{5},prefix{5},name((j-1)*300+i),suffix),format);
      end
  end
  
  
        %% %%%%%%%%%%%%%%%%%%%%%%%%LFM Signal CWD%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:length(power)
    for i =1:nd
        x = LFM_Code();
        S{j,i} = x + wgn(1,length(x),power(j));
    end
end


  for j =1:length(power)
      for i =1:nd
        CWD = choiwilliams(S{j,i});
        CWD = abs(CWD);
        CWD = (CWD-min(CWD))./(max(CWD)-min(CWD)); %generalization
        imwrite(CWD,strcat(path{6},prefix{6},name((j-1)*300+i),suffix),format);
      end
  end
  
  
        %% %%%%%%%%%%%%%%%%%%%%%%%%Costas Signal CWD%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:length(power)
    for i =1:nd
        x = Costas_Code();
        S{j,i} = x + wgn(1,length(x),power(j));
    end
end


  for j =1:length(power)
      for i =1:nd
        CWD = choiwilliams(S{j,i});
        CWD = abs(CWD);
        CWD = (CWD-min(CWD))./(max(CWD)-min(CWD)); %generalization
        imwrite(CWD,strcat(path{7},prefix{7},name((j-1)*300+i),suffix),format);
      end
  end
  
  
          %% %%%%%%%%%%%%%%%%%%%%%%%%Barker Signal CWD%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:length(power)
    for i =1:nd
        x = Barker_Code();
        S{j,i} = x + wgn(1,length(x),power(j));
    end
end


  for j =1:length(power)
      for i =1:nd
        CWD = choiwilliams(S{j,i});
        CWD = abs(CWD);
        CWD = (CWD-min(CWD))./(max(CWD)-min(CWD)); %generalization
        imwrite(CWD,strcat(path{8},prefix{8},name((j-1)*300+i),suffix),format);
      end
  end