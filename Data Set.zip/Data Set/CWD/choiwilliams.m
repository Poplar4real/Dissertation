    function [CWD]=choiwilliams(x)    
    
    
    N=length(x);         
    P=length(x)/2;       
    M = 2*P-1; 
    a = -P;              % for shifting input sequence
    b = P-1;             % and for-loop limits
    kern = zeros(N,N);   
    
    
    sigma = 1;
 

    if mod(N,2)~=0      % odd sequence
        x=[0 x];
        N=length(x);
         P=length(x)/2;       
         M = 2*P-1; 
         a = -P;              % for shifting input sequence
         b = P-1;             % and for-loop limits
         kern = zeros(N,N); 
    end

%% %%%%%%%%%%%% Computer the Wigner-Ville Distribution %%%%%%%%% %%
for mu =a:b
      y=shiftz(x,mu);
      x1(mu+P+1,:)=[y(1,P:M) 0 y(1:P-1)];
      x2(mu+P+1,:)=[fliplr(y(1,1:P)) 0 fliplr(y(1,P+1:M))];
      WV((mu+P+1),:) = x1(mu+P+1,:).*conj(x2(mu+P+1,:));
end

%% %%%%%%%%%%%%%% Compute the Choi Williams Kernel %%%%%%%%%%%%% %%
% The Choi Williams kernel is a summation of weighted WV outputs.
kern(:,1) = WV(:,1);
mu = b:-1:a;             % This is the same variable used to comput WV.
count = 0;
for L = a:b
  weight = zeros(N,N);           % Sets and resets weighting matrix
      for n = 1:P-1
          weight(:,n+1) = sqrt(sigma./(4*pi*n.^2)).*...
                          exp((-(mu-L).^2).*sigma./(4*n.^2));
          weight(:,N+1-n) = weight(:,n+1);
      end
   wf = weight(:,2:N).*WV(:,2:N); %Multiply weighting function by WV
   count = count+1;
   kern(N+1-count,2:N) = sum(wf(:,:)); %Kernel for a given time index, L  
end

%% %%%%%%%%%%%%%% Computer the Choi Williams Kernal %%%%%%%%%%%% %%
      kern = fliplr(kern');
      CWD=fft(kern);
      CWD=2*real(CWD);

    end

% End of M-file

