    function [y]=shiftz(x,n)
    % [y]=shift(x,n)
    % shift vector x by n to the right
    % shifting in zeros
    
    N = length(x)/2;

    if n >= 0           
       y = [zeros(1,n) x(1:2*N-n)];   % Shifting right
    else               
       n = abs(n);
       y = [x(1+n:2*N) zeros(1,n)];   % Shifting left
    end
