function x = T1_Code()
%myFun - Description
%
% Syntax: x = T1_Code()
%
% Long description
    

close all;
clear;
rng('shuffle','twister');                %seed for rand

    
fs = 1200e6; Ts = 1/fs;                    %sample frequency 
fc = fs/6 + rand*(fs/5-fs/6);              %carrier frequency
A=1;                                       %Amplitude
k = randi(3)+3;                              %Number of stepped frequency segments
m =2;                                      %Number of phase states 
N = 512 + randi(1920 - 512);
SAR = floor(fc/fs);
T = N*Ts;


index = 1;
for tt = 0:Ts:(N*Ts-Ts)
    jj = floor(k*tt/T);
    phase(index) = mod(((2*pi/m)*floor(((k*tt - jj*T)*(jj*m/T)))), 2*pi); 
    index = index + 1;
end

for i = 1: N
    I(i) = A*cos(2*pi*fc*(i-1)*Ts+phase(i));
    Q(i) = A*sin(2*pi*fc*(i-1)*Ts+phase(i));
end

x = I + sqrt(-1)*Q;
 

end