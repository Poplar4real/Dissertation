function x = P1_Code()
%myFun - Description
%This code is for generating P1 Code. 
% Syntax: x = Frank_Code()
%
% Long description

close all;
clear;
rng('shuffle','twister');                %seed for rand
    
fs = 1200e6; Ts = 1/fs;                    %sample frequency 
fc = fs/6 + rand*(fs/5-fs/6);            %carrier frequency
M = randi(3)+5;                          %random # of code phases                     
A = 1;                                   %Amplitude
SAR = ceil(fs/fc);                       %sampling ratio
N = 512 + randi(1920-512);               %length of samples
P = fix(N/(M*M*SAR));                    %periods of codes

%Generating the phase matrix
for i = 1:M
    for j = 1:M
        phi(i,j)=-pi/M*[M-(2*j-1)]*[(j-1)*M+(i-1)];        
    end    
end


index = 0;
for i = 1:M
    for j = 1:M
        for n = 1:SAR
            I(index+1)=A*cos(2*pi*fc*(n-1)*Ts+phi(i,j));
            Q(index+1)=A*sin(2*pi*fc*(n-1)*Ts+phi(i,j));
            index = index + 1;        
        end
    end    
end


temp1 = I; I=[];
temp2 = Q; Q=[];
for i =1:P
    I =[I temp1];
    Q =[Q temp2];
end

x = I+sqrt(-1).*Q; %modulated signal

end

