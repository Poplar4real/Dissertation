function x = LFM()
%myFun - Description
%This code if for generating LFM Code
% Syntax: x = LFM()
%
% Long description
 
close all;
clear;
rng('shuffle','twister');                %seed for rand    

fs = 1200e6; Ts = 1/fs;                    %sample frequency 
fc = fs/6 + rand*(fs/5-fs/6);            %carrier frequency
B = fs/20+rand*(fs/16-fs/20);            %Bandwidth
N = 512+randi(1920-512);                 %rand length of signal
T = N*Ts;                                %total time
k = B/T;
t = linspace(-T/2,T/2,N);                        %set up time vector


x = exp(1i*k*pi*t.^2);                   %LFM Signal

end